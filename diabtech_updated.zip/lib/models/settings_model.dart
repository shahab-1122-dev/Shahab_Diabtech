// TODO Implement this library.import 'package:hive/hive.dart';

import 'package:hive_flutter/hive_flutter.dart';

part 'settings_model.dart';

@HiveType(typeId: 1)
class SettingsModel extends HiveObject {
  @HiveField(0)
  bool isDarkMode;

  SettingsModel({required this.isDarkMode});
}
